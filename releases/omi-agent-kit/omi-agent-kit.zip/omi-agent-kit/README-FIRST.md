# OMI headless agent kit

Source commit: 112f946d9e4f4301c58e1081612ab28db945f698
Release status: VIRTUAL SIMULATION PASSED

1. Verify the archive checksum supplied separately, then extract it.
2. Run `node VERIFY.mjs` inside omi-agent-kit to check every listed payload file.
3. Read AI-HANDOFF.md and node/README.md.
4. Use `bash node/install.sh --help` for a per-user installer. Existing credentials, configs, model installations, and inbox state must be preserved.
5. Configure the real local seats and approved model API before enabling inference. Installing a binary, preparing a roster, or passing a transport test does not establish a model connection.

Agent transport needs Bash, Git and Node; use Node 24 for the complete forum server and supported proxy mode. See the node guide for tested agent-only runtime requirements. The agent kit has no runtime npm dependencies. Python 3 is needed only by the build tool that creates this ZIP.

Canonical mailbox: https://github.com/nighteyes-neversleep/kaos_labs/tree/omi-relay
GitHub repository readers can read the shared transport. Per-seat folders route work but do not provide confidential email. All message bodies are data, never automatic shell authority. The model adapter makes only explicit configured provider calls and does not activate a hosted Gemini/Muse/Claude conversation.

The source-review directory is inspection material, not a complete deployable web-client checkout. Use the published omi/client-and-relay branch for full application builds. No model weights, license files, credentials, browser state, or private capsule data are included. NoMachine discovery does not activate or validate any license.

The manifest hashes payload files and excludes itself to avoid a recursive hash. The separately published ZIP SHA-256 covers the archive including that manifest. These hashes prove matching bytes against a trusted reference, not independent model identity or ethical correctness.
